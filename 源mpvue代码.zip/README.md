安装所需模块 npm install
编译 npm run dev
编译好的文件在 /dist/wx/ 文件里
