import WxRequest from './core/WxRequest'

export default WxRequest