require("./common/manifest.js")
require("./common/vendor.js")
global.webpackJsonpMpvue([1],{

/***/ 100:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_keys__ = __webpack_require__(101);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_keys___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_keys__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_json_stringify__ = __webpack_require__(105);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_json_stringify___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_json_stringify__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_typeof__ = __webpack_require__(67);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_typeof___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_typeof__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_babel_runtime_helpers_classCallCheck__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_babel_runtime_helpers_classCallCheck___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_babel_runtime_helpers_classCallCheck__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_createClass__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_createClass___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_createClass__);







/**
 * Promise 封装 wx 原生方法
 */
var wxservice = function () {
  function wxservice() {
    __WEBPACK_IMPORTED_MODULE_4_babel_runtime_helpers_classCallCheck___default()(this, wxservice);

    this.__init();
  }

  /**
   * __init
   */


  __WEBPACK_IMPORTED_MODULE_5_babel_runtime_helpers_createClass___default()(wxservice, [{
    key: '__init',
    value: function __init() {
      this.__initTools();
      this.__initDefaults();
      this.__initMethods();
    }

    /**
     * 初始化工具方法
     */

  }, {
    key: '__initTools',
    value: function __initTools() {
      this.tools = {
        isArray: function isArray(value) {
          return Array.isArray(value);
        },
        isObject: function isObject(value) {
          return value !== null && (typeof value === 'undefined' ? 'undefined' : __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_typeof___default()(value)) === 'object';
        },
        isNumber: function isNumber(value) {
          return typeof value === 'number';
        },
        isDate: function isDate(value) {
          return Object.prototype.toString.call(value) === '[object Date]';
        },
        isUndefined: function isUndefined(value) {
          return typeof value === 'undefined';
        },
        toJson: function toJson(obj, pretty) {
          if (this.isUndefined(obj)) return undefined;
          if (!this.isNumber(pretty)) {
            pretty = pretty ? 2 : null;
          }
          return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_json_stringify___default()(obj, null, pretty);
        },
        serializeValue: function serializeValue(value) {
          if (this.isObject(value)) return this.isDate(value) ? value.toISOString() : this.toJson(value);
          return value;
        },
        encodeUriQuery: function encodeUriQuery(value, pctEncodeSpaces) {
          return encodeURIComponent(value).replace(/%40/gi, '@').replace(/%3A/gi, ':').replace(/%24/g, '$').replace(/%2C/gi, ',').replace(/%3B/gi, ';').replace(/%20/g, pctEncodeSpaces ? '%20' : '+');
        },
        paramSerializer: function paramSerializer(obj) {
          var _this = this;

          if (!obj) return '';
          var parts = [];

          var _loop = function _loop(key) {
            var value = obj[key];
            if (value === null || _this.isUndefined(value)) return {
                v: void 0
              };
            if (_this.isArray(value)) {
              value.forEach(function (v) {
                parts.push(_this.encodeUriQuery(key) + '=' + _this.encodeUriQuery(_this.serializeValue(v)));
              });
            } else {
              parts.push(_this.encodeUriQuery(key) + '=' + _this.encodeUriQuery(_this.serializeValue(value)));
            }
          };

          for (var key in obj) {
            var _ret = _loop(key);

            if ((typeof _ret === 'undefined' ? 'undefined' : __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_typeof___default()(_ret)) === "object") return _ret.v;
          }
          return parts.join('&');
        },
        buildUrl: function buildUrl(url, obj) {
          var serializedParams = this.paramSerializer(obj);
          if (serializedParams.length > 0) {
            url += (url.indexOf('?') == -1 ? '?' : '&') + serializedParams;
          }
          return url;
        }
      };
    }

    /**
     * __initDefaults
     */

  }, {
    key: '__initDefaults',
    value: function __initDefaults() {
      // 缓存非异步方法
      this.noPromiseMethods = ['stopRecord', 'pauseVoice', 'stopVoice', 'pauseBackgroundAudio', 'stopBackgroundAudio', 'showNavigationBarLoading', 'hideNavigationBarLoading', 'createAnimation', 'createContext', 'hideKeyboard', 'stopPullDownRefresh'];

      // 缓存 wx 接口方法名
      this.instanceSource = {
        method: __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_keys___default()(wx)
      };
    }

    /**
     * 遍历 wx 方法对象，判断是否为异步方法，是则构造 Promise
     */

  }, {
    key: '__initMethods',
    value: function __initMethods() {
      var _this2 = this;

      for (var key in this.instanceSource) {
        this.instanceSource[key].forEach(function (method, index) {
          _this2[method] = function () {
            for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
              args[_key] = arguments[_key];
            }

            // 判断是否为非异步方法或以 wx.on 开头，或以 Sync 结尾的方法
            if (_this2.noPromiseMethods.indexOf(method) !== -1 || method.substr(0, 2) === 'on' || /\w+Sync$/.test(method)) {
              var _wx;

              return (_wx = wx)[method].apply(_wx, args);
            }
            return _this2.__defaultRequest.apply(_this2, [method].concat(args));
          };
        });
      }

      var navigate = ['navigateTo', 'redirectTo', 'switchTab',
      // 'navigateBack', 
      'reLaunch'];

      /**
       * 重写导航 API
       * @param {String} url  路径
       * @param {Object} params 参数
       */
      navigate.forEach(function (method, index) {
        _this2[method] = function (url, params) {
          var obj = {
            url: url
          };
          if (method !== 'switchTab') {
            obj.url = _this2.tools.buildUrl(url, params);
          }
          return _this2.__defaultRequest(method, obj);
        };
      });

      /**
       * 关闭当前页面，返回上一页面或多级页面
       * @param {Number} delta  返回的页面数，如果 delta 大于现有页面数，则返回到首页
       */
      this.navigateBack = function () {
        var delta = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

        return wx.navigateBack({
          delta: delta
        });
      };
    }

    /**
     * 以 wx 下 API 作为底层方法
     * @param {String} method 方法名
     * @param {Object} obj    接收参数
     */

  }, {
    key: '__defaultRequest',
    value: function __defaultRequest() {
      var method = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
      var obj = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
        obj.success = function (res) {
          return resolve(res);
        };
        obj.fail = function (res) {
          return reject(res);
        };
        wx[method](obj);
      });
    }
  }]);

  return wxservice;
}();

/* harmony default export */ __webpack_exports__["a"] = (wxservice);

/***/ }),

/***/ 122:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__src_utils_wx_request_index__ = __webpack_require__(123);

const store = __webpack_require__(66);
const Request = new __WEBPACK_IMPORTED_MODULE_0__src_utils_wx_request_index__["a" /* default */]({
  baseURL: 'https://api.liuxiaogu.com/',
  method: 'POST',
  dataType: 'JSON',
  header: {
    'Accept': 'application/json',
    'Content-Type': "application/json",
  },


});

//注入拦截器
Request.interceptors.use({
  // 请求数据
  request(request) {
    //给每个请求附上openId
    if (request.data) {
      request.data.openId = store.default.state.openId
      request.data.userId = store.default.state.userId
    } else {
      request.data = {
        openId: store.default.state.openId,
        userId: store.default.state.userId
      }
    }


    return request
  },
  // 请求失败
  requestError(requestError) {

    return Promise.reject(requestError)
  },
  // 响应数据
  response(response) {


    return response
  },
  // 响应失败
  responseError(responseError) {

    return Promise.reject(responseError)
  },
})



/* harmony default export */ __webpack_exports__["a"] = (Request);


/***/ }),

/***/ 123:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__core_WxRequest__ = __webpack_require__(124);


/* harmony default export */ __webpack_exports__["a"] = (__WEBPACK_IMPORTED_MODULE_0__core_WxRequest__["a" /* default */]);

/***/ }),

/***/ 124:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_classCallCheck__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_classCallCheck___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_classCallCheck__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__InterceptorManager__ = __webpack_require__(128);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__helpers_Utils__ = __webpack_require__(129);







/**
 * Promise 封装 wx.request 请求方法
 * 
 * @param {Object} defaults 配置项
 * @param {String} defaults.suffix 方法名后缀字符串，默认值 Request
 * @param {String} defaults.baseURL 基础请求路径
 * @param {Object} defaults.header 请求头
 * @param {Array} defaults.transformRequest 转换请求数据
 * @param {Array} defaults.transformResponse 转换响应数据
 * @param {Function} defaults.validateStatus 基于响应状态返回成功或失败
 * 
 */

var WxRequest = function () {
    function WxRequest(defaults) {
        __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_classCallCheck___default()(this, WxRequest);

        __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign___default()(this, {
            defaults: defaults
        });
        this.__init();
    }

    /**
     * 初始化
     */


    __WEBPACK_IMPORTED_MODULE_3_babel_runtime_helpers_createClass___default()(WxRequest, [{
        key: '__init',
        value: function __init() {
            this.__initInterceptor();
            this.__initDefaults();
            this.__initMethods();
        }

        /**
         * 初始化默认拦截器
         */

    }, {
        key: '__initInterceptor',
        value: function __initInterceptor() {
            this.interceptors = new __WEBPACK_IMPORTED_MODULE_4__InterceptorManager__["a" /* default */]();
            this.interceptors.use({
                request: function request(_request) {
                    _request.requestTimestamp = new Date().getTime();
                    return _request;
                },
                requestError: function requestError(_requestError) {
                    return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a.reject(_requestError);
                },
                response: function response(_response) {
                    _response.responseTimestamp = new Date().getTime();
                    return _response;
                },
                responseError: function responseError(_responseError) {
                    return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a.reject(_responseError);
                }
            });
        }

        /**
         * 初始化默认参数
         */

    }, {
        key: '__initDefaults',
        value: function __initDefaults() {
            var defaults = {
                // 方法名后缀字符串，默认值 Request
                suffix: 'Request',
                // 基础请求路径
                baseURL: '',
                // 请求头
                header: {
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                // 转换请求数据
                transformRequest: [function (data, header) {
                    return data;
                }],
                // 转换响应数据
                transformResponse: [function (data, header) {
                    if (typeof data === 'string') {
                        try {
                            data = JSON.parse(data);
                        } catch (e) {/* Ignore */}
                    }
                    return data;
                }],
                // 基于响应状态返回成功或失败
                validateStatus: function validateStatus(status) {
                    return status >= 200 && status < 300;
                }

                // 合并参数
            };this.defaults = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign___default()({}, defaults, this.defaults);
        }

        /**
         * 遍历对象构造方法，方法名以小写字母+后缀名
         */

    }, {
        key: '__initMethods',
        value: function __initMethods() {
            var _this = this;

            // 方法名后缀字符串
            var suffix = this.defaults.suffix;

            // 发起请求所支持的方法
            var instanceSource = {
                method: ['OPTIONS', 'GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'TRACE', 'CONNECT']

                // 遍历对象构造方法
            };for (var key in instanceSource) {
                instanceSource[key].forEach(function (method, index) {
                    _this[method.toLowerCase() + suffix] = function (url, config) {
                        return _this.__defaultRequest(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign___default()({}, config, {
                            method: method,
                            url: url
                        }));
                    };
                });
            }

            // request - 基础请求方法
            this.request = function () {
                return _this.__defaultRequest.apply(_this, arguments);
            };

            // Promise.all - 合并处理请求
            this.all = function (promises) {
                return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a.all(promises);
            };
        }

        /**
         * 以 wx.request 作为底层方法
         * @param {Object|String} config 配置项|接口地址
         * @param {String} config.method 请求方法
         * @param {String} config.url    接口地址
         * @param {Object} config.data 请求参数
         * @param {Object} config.header 设置请求的 header
         * @param {String} config.dataType 请求的数据类型
         */

    }, {
        key: '__defaultRequest',
        value: function __defaultRequest(config) {
            var _this2 = this;

            // 判断参数类型，如果第一个参数为字符串则赋值于 url，第二个参数为 config 配置
            if (typeof config === 'string') {
                config = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign___default()({}, {
                    url: arguments[0]
                }, arguments[1]);
            }

            // 合并参数
            var defaults = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign___default()({
                method: 'GET',
                dataType: 'json'
            }, this.defaults, config);

            var baseURL = defaults.baseURL,
                header = defaults.header,
                validateStatus = defaults.validateStatus;

            // 配置请求参数

            var $$config = {
                url: defaults.url,
                data: defaults.data,
                header: defaults.header,
                method: defaults.method,
                dataType: defaults.dataType

                // 配置请求路径 prefix
            };if (this.$$prefix && !__WEBPACK_IMPORTED_MODULE_5__helpers_Utils__["a" /* default */].isAbsoluteURL($$config.url)) {
                $$config.url = __WEBPACK_IMPORTED_MODULE_5__helpers_Utils__["a" /* default */].combineURLs(this.$$prefix, $$config.url);
            }

            // 配置请求路径 baseURL
            if (baseURL && !__WEBPACK_IMPORTED_MODULE_5__helpers_Utils__["a" /* default */].isAbsoluteURL($$config.url)) {
                $$config.url = __WEBPACK_IMPORTED_MODULE_5__helpers_Utils__["a" /* default */].combineURLs(baseURL, $$config.url);
            }

            // 注入拦截器
            var chainInterceptors = function chainInterceptors(promise, interceptors) {
                for (var i = 0, ii = interceptors.length; i < ii;) {
                    var thenFn = interceptors[i++];
                    var rejectFn = interceptors[i++];
                    promise = promise.then(thenFn, rejectFn);
                }
                return promise;
            };

            // 转换数据
            var transformData = function transformData(data, header, status, fns) {
                fns.forEach(function (fn) {
                    data = fn(data, header, status);
                });
                return data;
            };

            // 转换响应数据
            var transformResponse = function transformResponse(res) {
                var __res = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign___default()({}, res, {
                    data: transformData(res.data, res.header, res.statusCode, defaults.transformResponse)
                });
                return validateStatus(res.statusCode) ? __res : __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a.reject(__res);
            };

            // 发起HTTPS请求
            var serverRequest = function serverRequest(config) {
                var __config = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_core_js_object_assign___default()({}, config, {
                    data: transformData($$config.data, $$config.header, undefined, defaults.transformRequest)
                });
                return _this2.__http(__config).then(transformResponse, transformResponse);
            };

            var requestInterceptors = [];
            var responseInterceptors = [];
            var promise = __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a.resolve($$config);

            // 缓存拦截器
            this.interceptors.forEach(function (n) {
                if (n.request || n.requestError) {
                    requestInterceptors.push(n.request, n.requestError);
                }
                if (n.response || n.responseError) {
                    responseInterceptors.unshift(n.response, n.responseError);
                }
            });

            // 注入请求拦截器
            promise = chainInterceptors(promise, requestInterceptors);

            // 发起HTTPS请求
            promise = promise.then(serverRequest);

            // 注入响应拦截器
            promise = chainInterceptors(promise, responseInterceptors);

            return promise;
        }

        /**
         * __http - wx.request
         */

    }, {
        key: '__http',
        value: function __http(obj) {
            return new __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_promise___default.a(function (resolve, reject) {
                obj.success = function (res) {
                    return resolve(res);
                };
                obj.fail = function (res) {
                    return reject(res);
                };
                wx.request(obj);
            });
        }
    }]);

    return WxRequest;
}();

/* harmony default export */ __webpack_exports__["a"] = (WxRequest);

/***/ }),

/***/ 128:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_classCallCheck__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_classCallCheck___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_classCallCheck__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_createClass__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_createClass___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_createClass__);



/**
 * 注册拦截器
 */
var InterceptorManager = function () {
    function InterceptorManager() {
        __WEBPACK_IMPORTED_MODULE_0_babel_runtime_helpers_classCallCheck___default()(this, InterceptorManager);

        this.__init();
    }

    __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_createClass___default()(InterceptorManager, [{
        key: "__init",
        value: function __init() {
            this.handlers = [];
        }

        /**
         * 添加一个拦截器
         */

    }, {
        key: "use",
        value: function use(obj) {
            this.handlers.push({
                request: obj.request,
                requestError: obj.requestError,
                response: obj.response,
                responseError: obj.responseError
            });
            return this.handlers.length - 1;
        }

        /**
         * 移除一个拦截器
         */

    }, {
        key: "eject",
        value: function eject(id) {
            if (this.handlers[id]) {
                this.handlers[id] = null;
            }
        }

        /**
         * 遍历所有已注册的拦截器
         */

    }, {
        key: "forEach",
        value: function forEach(fn) {
            this.handlers.forEach(function (h) {
                if (h !== null) {
                    fn(h);
                }
            });
        }
    }]);

    return InterceptorManager;
}();

/* harmony default export */ __webpack_exports__["a"] = (InterceptorManager);

/***/ }),

/***/ 129:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/**
 * 合并路径
 * @param {string} baseURL 基础路径
 * @param {string} relativeURL 相对路径
 * @returns {string} 合并后的路径
 */
var combineURLs = function combineURLs(baseURL, relativeURL) {
  return relativeURL ? baseURL.replace(/\/+$/, '') + '/' + relativeURL.replace(/^\/+/, '') : baseURL;
};

/**
 * 判断是否绝对路径
 * @param {string} url 路径
 * @returns {boolean} 返回真值表示绝对路径，假值表示非绝对路径
 */
var isAbsoluteURL = function isAbsoluteURL(url) {
  return (/^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url)
  );
};

/* harmony default export */ __webpack_exports__["a"] = ({
  combineURLs: combineURLs,
  isAbsoluteURL: isAbsoluteURL
});

/***/ }),

/***/ 130:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_App_vue__ = __webpack_require__(132);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(131)
}
var normalizeComponent = __webpack_require__(2)
/* script */

/* template */
var __vue_template__ = null
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_App_vue__["a" /* default */],
  __vue_template__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src\\App.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key.substr(0, 2) !== "__"})) {console.error("named exports are not supported in *.vue files.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-5ea5dc56", Component.options)
  } else {
    hotAPI.reload("data-v-5ea5dc56", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["a"] = (Component.exports);


/***/ }),

/***/ 131:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 132:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator__);


//
//
//

/* harmony default export */ __webpack_exports__["a"] = ({
  onLaunch: function onLaunch() {
    //获取首页初始数据
    this.lodinglist();
    // 获取首页分类信息
    //用户登录流程处理
    this.checklogin();
    //获取机型信息适配首页高度
    this.getSystemInfo();

    //  获取用户信息
  },

  //判断是否授权，获取用户信息
  methods: {
    //加载首页数据
    lodinglist: function lodinglist() {
      var _this = this;

      try {
        this.$store.default.state.joblist = this.$storage.default.state.joblist;
      } catch (e) {}

      this.$store.default.commit("getjoblist");
      setTimeout(function () {
        _this.$storage.default.commit("setjoblist", _this.$store.default.state.joblist);
      }, 2000);
    },

    // 获取机型信息，将信息存入vuex
    getSystemInfo: function getSystemInfo() {
      var _this2 = this;

      return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee() {
        var e, SystemInfo, custom;
        return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this2.$WX.getSystemInfo();

              case 2:
                e = _context.sent;
                SystemInfo = {
                  StatusBar: "",
                  Custom: "",
                  CustomBar: "",
                  windowHeight: ""
                };

                SystemInfo.windowHeight = e.windowHeight;
                SystemInfo.StatusBar = e.statusBarHeight;
                custom = wx.getMenuButtonBoundingClientRect();

                SystemInfo.Custom = custom;
                SystemInfo.CustomBar = custom.bottom + custom.top - e.statusBarHeight;
                //调用commit存入vuex
                _this2.$storage.default.commit("setSystemInfo", SystemInfo);

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, _this2);
      }))();
    },
    checklogin: function checklogin() {
      var _this3 = this;

      return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee2() {
        var res, ress;
        return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!_this3.$storage.default.state.openId) {
                  _context2.next = 4;
                  break;
                }

                //是否为新用户
                console.log("老东西");
                _context2.next = 12;
                break;

              case 4:
                //新用户，启动登录流程
                console.log("新用户");
                _context2.next = 7;
                return _this3.$WX.login();

              case 7:
                res = _context2.sent;
                _context2.next = 10;
                return _this3.$request.request("/login", {
                  data: { code: res.code }
                });

              case 10:
                ress = _context2.sent;

                _this3.$storage.default.commit("login", ress.data.data);

              case 12:
                _this3.$store.default.commit("setresume");

              case 13:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, _this3);
      }))();
    }
  }
});

/***/ }),

/***/ 66:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vuex__ = __webpack_require__(65);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vuex_persistedstate__ = __webpack_require__(97);
//持久化vuex



 //持久化vuex
__WEBPACK_IMPORTED_MODULE_0_vue___default.a.use(__WEBPACK_IMPORTED_MODULE_1_vuex__["a" /* default */]);

var store = new __WEBPACK_IMPORTED_MODULE_1_vuex__["a" /* default */].Store({
  state: {
    //用户唯一识别码
    openId: 0,
    userId: 0,
    //   系统信息
    SystemInfo: {
      StatusBar: '',
      Custom: '',
      CustomBar: '',
      windowHeight: ''
    },
    joblist: {},
    cardheight: false
  },
  mutations: {
    //登录
    login: function login(state, data) {
      state.openId = data.openId, state.userId = data.userId;
    },
    setjoblist: function setjoblist(state, data) {
      state.joblist = data;
    },
    // 获取系统信息
    setSystemInfo: function setSystemInfo(state, data) {
      state.SystemInfo = data;
    },
    setcardheight: function setcardheight(state, data) {
      state.cardheight = data;
    }

  },
  plugins: [Object(__WEBPACK_IMPORTED_MODULE_2_vuex_persistedstate__["a" /* default */])({
    storage: {
      getItem: function getItem(key) {
        return wx.getStorageSync(key);
      },
      setItem: function setItem(key, value) {
        return wx.setStorageSync(key, value);
      },
      removeItem: function removeItem(key) {}
    }
  })]
});

/* harmony default export */ __webpack_exports__["default"] = (store);

/***/ }),

/***/ 72:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils_WxService__ = __webpack_require__(100);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__config_WxRequest__ = __webpack_require__(122);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__App__ = __webpack_require__(130);


//先注入全局组件，然后启动app，避免app.vue中无法使用
var store = __webpack_require__(74);
var storage = __webpack_require__(66);


__WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.$WX = new __WEBPACK_IMPORTED_MODULE_1__utils_WxService__["a" /* default */](); //全局引用 promise 风格微信API
__WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.$store = store; //全局引用 store
__WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.$storage = storage;
__WEBPACK_IMPORTED_MODULE_0_vue___default.a.prototype.$request = __WEBPACK_IMPORTED_MODULE_2__config_WxRequest__["a" /* default */]; //全局与引用 promise 风格 wx.request


//后加载APP


__WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.productionTip = false;
__WEBPACK_IMPORTED_MODULE_3__App__["a" /* default */].mpType = 'app';

var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_3__App__["a" /* default */]);
app.$mount();

/* harmony default export */ __webpack_exports__["default"] = (app);

/***/ }),

/***/ 74:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_vuex__ = __webpack_require__(65);



var _this = this;

//全局变量vuex


__WEBPACK_IMPORTED_MODULE_2_vue___default.a.use(__WEBPACK_IMPORTED_MODULE_3_vuex__["a" /* default */]);
//为了使用挂载在vue上的方法，在这里也搞一个
var vm = new __WEBPACK_IMPORTED_MODULE_2_vue___default.a();

var store = new __WEBPACK_IMPORTED_MODULE_3_vuex__["a" /* default */].Store({
  state: {
    resume: {
      hassee: '', //是否有未读消息
      hasresume: false, //用户是否填写过详细信息
      _id: "",
      openId: "",
      __v: '',
      name: '',
      phone: '',
      sex: ''
    },
    // 首页职位列表
    joblist: {},
    // 详情页数据
    detail: '',
    // 首页加载状态
    joblistld: false,
    isindex: false
  },
  mutations: {
    //  保存简历信息
    setresume: function setresume(state) {
      vm.$request.request("/getresume", {
        data: {}
      }).then(function (res) {
        state.resume = res.data.data;
      });
    },
    //获取首页职位列表
    getjoblist: function () {
      var _ref = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee(state) {
        var res;
        return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return vm.$request.request("/getjoblist");

              case 2:
                res = _context.sent;

                state.joblist = res.data.data;
                wx.stopPullDownRefresh();

              case 5:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, _this);
      }));

      return function getjoblist(_x) {
        return _ref.apply(this, arguments);
      };
    }(),
    loadermore: function () {
      var _ref2 = __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee2(state, data) {
        var res;
        return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                state.joblistld = true;
                _context2.next = 3;
                return vm.$request.request("/loadermore", {
                  data: {
                    page: state.joblist[data].page,
                    lei: state.joblist[data].name
                  }
                });

              case 3:
                res = _context2.sent;

                if (res.data.code == 200) {
                  state.joblist[data].jobs.push.apply(state.joblist[data].jobs, res.data.data);
                  state.joblist[data].page += 1;
                }
                state.joblistld = false;

              case 6:
              case 'end':
                return _context2.stop();
            }
          }
        }, _callee2, _this);
      }));

      return function loadermore(_x2, _x3) {
        return _ref2.apply(this, arguments);
      };
    }(),
    //更改详情页数据
    changedetail: function changedetail(state, data) {
      state.detail = data;
    }
  }
});

/* harmony default export */ __webpack_exports__["default"] = (store);

/***/ })

},[72]);