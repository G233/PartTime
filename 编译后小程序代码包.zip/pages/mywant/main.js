require("../../common/manifest.js")
require("../../common/vendor.js")
global.webpackJsonpMpvue([5],{

/***/ 185:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(186);



// add this to handle exception
__WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
  if (console && console.error) {
    console.error(err);
  }
};

var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
app.$mount();

/***/ }),

/***/ 186:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(188);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_7466b386_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(189);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(187)
}
var normalizeComponent = __webpack_require__(2)
/* script */

/* template */

/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_7466b386_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src\\pages\\mywant\\index.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key.substr(0, 2) !== "__"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-7466b386", Component.options)
  } else {
    hotAPI.reload("data-v-7466b386", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["a"] = (Component.exports);


/***/ }),

/***/ 187:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 188:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_get_iterator__ = __webpack_require__(47);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_get_iterator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_get_iterator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_asyncToGenerator__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_asyncToGenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_asyncToGenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_jobcard__ = __webpack_require__(48);



//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



var _require = __webpack_require__(11),
    $Message = _require.$Message;

/* harmony default export */ __webpack_exports__["a"] = ({
  components: { JobCard: __WEBPACK_IMPORTED_MODULE_3__components_jobcard__["a" /* default */] },
  data: function data() {
    return {
      btnclass: ["btn cu-btn round bg-blue shadow-lg  shadow-blur lg animated ", "fadeInUpBig"],
      visible: false,
      lists: [],
      list1: []
    };
  },
  onUnload: function onUnload() {
    var _this = this;

    return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default.a.mark(function _callee() {
      return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _this.truedelete();

            case 1:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, _this);
    }))();
  },
  onShow: function onShow() {
    wx.showNavigationBarLoading();
    this.refresh();
  },

  methods: {
    truedelete: function truedelete() {
      var _this2 = this;

      return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default.a.mark(function _callee2() {
        var _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, x, msg;

        return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _iteratorNormalCompletion = true;
                _didIteratorError = false;
                _iteratorError = undefined;
                _context2.prev = 3;
                _iterator = __WEBPACK_IMPORTED_MODULE_0_babel_runtime_core_js_get_iterator___default()(_this2.lists);

              case 5:
                if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                  _context2.next = 14;
                  break;
                }

                x = _step.value;

                if (!x.willd) {
                  _context2.next = 11;
                  break;
                }

                _context2.next = 10;
                return _this2.$request.request("/deletewant", {
                  data: { jobId: x.jobId._id }
                });

              case 10:
                msg = _context2.sent;

              case 11:
                _iteratorNormalCompletion = true;
                _context2.next = 5;
                break;

              case 14:
                _context2.next = 20;
                break;

              case 16:
                _context2.prev = 16;
                _context2.t0 = _context2["catch"](3);
                _didIteratorError = true;
                _iteratorError = _context2.t0;

              case 20:
                _context2.prev = 20;
                _context2.prev = 21;

                if (!_iteratorNormalCompletion && _iterator.return) {
                  _iterator.return();
                }

              case 23:
                _context2.prev = 23;

                if (!_didIteratorError) {
                  _context2.next = 26;
                  break;
                }

                throw _iteratorError;

              case 26:
                return _context2.finish(23);

              case 27:
                return _context2.finish(20);

              case 28:
                _this2.list1 = [];
                _this2.visible = false;

              case 30:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, _this2, [[3, 16, 20, 28], [21,, 23, 27]]);
      }))();
    },
    repeal: function repeal() {
      var _this3 = this;

      var x = this.list1.pop();
      this.lists[x].willd = false;
      if (this.list1.length == 0) {
        this.btnclass[1] = "fadeOutDownBig";
        setTimeout(function () {
          _this3.visible = false;
        }, 1000);
      }
      $Message({
        content: "撤销成功！",
        type: "success"
      });
    },
    longpress: function longpress(index) {
      if (this.lists[index].jobId.done) {}
      this.lists[index].willd = true;
      this.list1.push(index);
      this.btnclass[1] = "fadeInUpBig";
      this.visible = true;
      $Message({
        content: "取消申请成功！",
        type: "success"
      });
    },
    refresh: function refresh() {
      var _this4 = this;

      return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default.a.mark(function _callee3() {
        var list;
        return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return _this4.$request.postRequest("/getwant");

              case 2:
                list = _context3.sent;

                _this4.lists = list.data.data;
                wx.hideNavigationBarLoading();

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, _this4);
      }))();
    },

    //跳转详情页
    gotodetail: function gotodetail(e) {
      var _this5 = this;

      return __WEBPACK_IMPORTED_MODULE_2_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default.a.mark(function _callee4() {
        return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_regenerator___default.a.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _this5.truedelete();
                _this5.$WX.navigateTo("../detail/main", { id: e._id });

              case 2:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, _this5);
      }))();
    }
  }
});

/***/ }),

/***/ 189:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('view', {
    staticClass: "text-grey padding text-xs",
    attrs: {
      "eventid": '0'
    },
    on: {
      "click": _vm.longpress
    }
  }, [_vm._v("tip:长按可取消申请")]), _vm._v(" "), (this.lists[0]) ? _c('i-spin', {
    attrs: {
      "custom": "",
      "mpcomid": '0'
    }
  }, [_c('view', {
    staticClass: "loading"
  })]) : _vm._e(), _vm._v(" "), (_vm.lists.length == 0) ? _c('i-cell', {
    attrs: {
      "title": "你还没有申请工作呀！",
      "mpcomid": '1'
    }
  }) : _vm._e(), _vm._v(" "), _vm._l((_vm.lists), function(item, index) {
    return _c('div', {
      key: index
    }, [_c('div', {
      directives: [{
        name: "show",
        rawName: "v-show",
        value: (!item.willd),
        expression: "!item.willd"
      }],
      attrs: {
        "eventid": '1_' + index
      },
      on: {
        "click": function($event) {
          _vm.gotodetail(item.jobId)
        },
        "longpress": function($event) {
          _vm.longpress(index)
        }
      }
    }, [_c('JobCard', {
      attrs: {
        "iscard": true,
        "hasstatu": true,
        "job": item.jobId,
        "mpcomid": '2_' + index
      }
    })], 1)])
  }), _vm._v(" "), (_vm.visible) ? _c('button', {
    class: _vm.btnclass,
    attrs: {
      "eventid": '2'
    },
    on: {
      "click": _vm.repeal
    }
  }, [_vm._v("撤销")]) : _vm._e(), _vm._v(" "), _c('i-message', {
    attrs: {
      "id": "message",
      "mpcomid": '3'
    }
  })], 2)
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-7466b386", esExports)
  }
}

/***/ })

},[185]);