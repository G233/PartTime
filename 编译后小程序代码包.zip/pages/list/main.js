require("../../common/manifest.js")
require("../../common/vendor.js")
global.webpackJsonpMpvue([9],{

/***/ 164:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(165);



// add this to handle exception
__WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
  if (console && console.error) {
    console.error(err);
  }
};

var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
app.$mount();

/***/ }),

/***/ 165:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(167);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_5d4867a8_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(168);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(166)
}
var normalizeComponent = __webpack_require__(2)
/* script */

/* template */

/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-5d4867a8"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_5d4867a8_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src\\pages\\list\\index.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key.substr(0, 2) !== "__"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-5d4867a8", Component.options)
  } else {
    hotAPI.reload("data-v-5d4867a8", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["a"] = (Component.exports);


/***/ }),

/***/ 166:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 167:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_jobcard__ = __webpack_require__(48);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

//登录页面


var _require = __webpack_require__(11),
    $Toast = _require.$Toast;

/* harmony default export */ __webpack_exports__["a"] = ({
  components: { JobCard: __WEBPACK_IMPORTED_MODULE_0__components_jobcard__["a" /* default */] },
  data: function data() {
    return {
      visible: false,
      actions: [{
        name: "取消"
      }, {
        name: "前往",
        color: "#ed3f14"
      }],
      isindex: true,
      height: 150,
      scrollTop: [],
      fenglei: "",
      addimg: ["image1", "shadow-lg", ""], //添加按钮动画控制
      sortiron: "unfold",
      sort: "顺序",
      type: "collection",
      flag: true,
      current_scroll: 0,
      color: "#fff",
      hasjob: false,

      images: ["../../static/images/add.png"],
      array: ["一天内", "一周内", "一月内", "半年内", "全部"],
      index: 4,
      duration: 400
    };
  },

  watch: {
    jobs: function jobs(newQuestion, oldQuestion) {
      if (!this.hasjob) {
        this.getFields();
        this.hasjob = true;
      }
    }
  },
  computed: {
    // 当数据还未接收到的时候计算属性会报错，所以使用了try
    hasresume: function hasresume() {
      try {
        return this.$store.default.state.resume.hasresume;
      } catch (e) {
        return false;
      }
    },
    loding: function loding() {
      return this.$store.default.state.joblistld;
    },
    jobs: function jobs() {
      try {
        return this.$store.default.state.joblist;
      } catch (e) {
        return "";
      }
    },

    //列表长度自适应
    listheight: function listheight() {
      var x;
      try {
        if (this.jobs[this.current_scroll].jobs.length < 5) {
          x = "height:" + (this.$storage.default.state.SystemInfo.windowHeight - 65) + "px";
        } else {
          var y = this.jobs[this.current_scroll].jobs.length * this.height + 64;
          x = "height:" + y + "px";
        }
      } catch (e) {
        x = "height:" + (this.$storage.default.state.SystemInfo.windowHeight - 65) + "px";
      }
      return x;
    }
  },
  onShow: function onShow() {
    var _this = this;

    // 是否处于首页，用于点击底部tab刷新
    setTimeout(function () {
      _this.$store.default.state.isindex = true;
    }, 200);
  },
  onHide: function onHide() {
    this.$store.default.state.isindex = false;
  },

  onLoad: function onLoad(options) {
    // 打开首页时判断options.Id是否存在 用这个值来判断进入首页的来源是否为用户点击了分享的卡片
    if (options.id) {
      setTimeout(function () {
        wx.navigateTo({
          url: "../detail/main?id=" + options.id
        });
      }, 0);
    }
  },
  // 点击tab刷新
  onTabItemTap: function onTabItemTap(_ref) {
    var index = _ref.index;

    if (index == 0) {
      if (this.$store.default.state.isindex) {
        wx.startPullDownRefresh();
        wx.pageScrollTo({
          scrollTop: 0,
          duration: 300
        });
        this.shuaxin();
      }
    }
  },
  onReady: function onReady() {
    var _this2 = this;

    try {
      setTimeout(function () {
        _this2.getFields();
      }, 1000);
    } catch (e) {
      return;
    }
  },
  onReachBottom: function onReachBottom() {
    this.loaderjob(this.current_scroll);
  },
  onPullDownRefresh: function onPullDownRefresh() {
    this.shuaxin();
  },

  // 判断上下滑动，控制添加按钮动画
  onPageScroll: function onPageScroll(_ref2) {
    var scrollTop = _ref2.scrollTop;

    if (this.scrollTop[this.current_scroll] > scrollTop) {
      if (!this.flag) {
        this.addimg[2] = "donghuaS";
        this.flag = true;
      }
    } else {
      if (this.flag) {
        this.addimg[2] = "donghuaH";
        this.flag = false;
      }
    }
    this.scrollTop[this.current_scroll] = scrollTop;
    //console.log(this.scrollTop);
  },

  methods: {
    // 获取职位卡片高度，计算首页高度
    getFields: function getFields() {
      var _this3 = this;

      try {
        wx.createSelectorQuery().select("#card").fields({
          size: true
        }, function (res) {
          _this3.height = res.height;
        }).exec();
      } catch (e) {}
    },
    shuaxin: function shuaxin() {
      this.$store.default.commit("getjoblist");
    },

    // 滑动tab保持上次浏览位置
    handleChangeScroll: function handleChangeScroll(e) {
      this.current_scroll = e;
      wx.pageScrollTo({
        scrollTop: this.scrollTop[e],
        duration: 0
      });
    },
    swiperchange: function swiperchange(e) {
      var _this4 = this;

      this.current_scroll = e.mp.detail.current;
      setTimeout(function () {
        _this4.$WX.pageScrollTo({
          scrollTop: _this4.scrollTop[_this4.current_scroll],
          duration: 0
        });
      }, 0.5);
    },
    changeCollection: function changeCollection() {
      this.works.Collection = !this.works.Collection;
    },
    bindPickerChange: function bindPickerChange(res) {
      this.index = res.mp.detail.value;
    },
    gotodetail: function gotodetail(e) {
      this.$WX.navigateTo("../detail/main", { id: e._id });
    },
    addjob: function addjob() {
      if (!this.hasresume) {
        this.visible = true;
        return;
      }
      this.$WX.navigateTo("../addjob/main");
    },
    handleClick: function handleClick(e) {
      if (e.mp.detail.index == 1) {
        this.$WX.navigateTo("../resume/main");
      }
      this.visible = false;
    },

    // 加载函数
    loaderjob: function loaderjob(e) {
      this.$store.default.commit("loadermore", e);
    },

    //刷新函数
    refresh: function refresh(e) {
      $Toast({
        content: "加载中",
        type: "loading"
      });
      this.$store.default.commit("getjoblist");
    }
  }
});

/***/ }),

/***/ 168:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('div', {
    staticClass: "tabs shadow"
  }, [_c('i-tabs', {
    attrs: {
      "current": _vm.current_scroll,
      "color": _vm.color,
      "mpcomid": '1'
    }
  }, _vm._l((_vm.jobs), function(item, index) {
    return _c('div', {
      key: index
    }, [_c('i-tab', {
      key: index,
      attrs: {
        "title": item.name,
        "eventid": '0_' + index,
        "mpcomid": '0_' + index
      },
      on: {
        "click": function($event) {
          _vm.handleChangeScroll(index)
        }
      }
    })], 1)
  }))], 1), _vm._v(" "), _c('div', {
    staticStyle: {
      "height": "42px"
    }
  }), _vm._v(" "), _c('swiper', {
    style: (_vm.listheight),
    attrs: {
      "duration": _vm.duration,
      "current": _vm.current_scroll,
      "eventid": '2'
    },
    on: {
      "change": _vm.swiperchange
    }
  }, _vm._l((_vm.jobs), function(item1, index) {
    return _c('block', {
      key: item1._id
    }, [_c('swiper-item', {
      attrs: {
        "id": "test",
        "mpcomid": '4_' + index
      }
    }, [_vm._l((item1.jobs), function(item, _index) {
      return _c('div', {
        key: _index
      }, [_c('div', {
        attrs: {
          "id": "card",
          "eventid": '1_' + index + '-' + _index
        },
        on: {
          "click": function($event) {
            _vm.gotodetail(item)
          }
        }
      }, [_c('JobCard', {
        attrs: {
          "job": item,
          "mpcomid": '2_' + index + '-' + _index
        }
      })], 1)])
    }), _vm._v(" "), _c('i-load-more', {
      attrs: {
        "id": "bt",
        "tip": "真没了",
        "loading": _vm.loding,
        "mpcomid": '3_' + index
      }
    })], 2)], 1)
  })), _vm._v(" "), _c('img', {
    class: _vm.addimg,
    attrs: {
      "src": _vm.images[0],
      "eventid": '3'
    },
    on: {
      "click": _vm.addjob
    }
  }), _vm._v(" "), _c('i-modal', {
    attrs: {
      "title": "完善资料",
      "visible": _vm.visible,
      "actions": _vm.actions,
      "eventid": '4',
      "mpcomid": '5'
    },
    on: {
      "Click": _vm.handleClick
    }
  }, [_c('view', [_vm._v("完善个人资料后即可发布")])]), _vm._v(" "), _c('i-toast', {
    attrs: {
      "id": "toast",
      "mpcomid": '6'
    }
  })], 1)
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-5d4867a8", esExports)
  }
}

/***/ })

},[164]);