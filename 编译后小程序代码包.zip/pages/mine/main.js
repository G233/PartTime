require("../../common/manifest.js")
require("../../common/vendor.js")
global.webpackJsonpMpvue([7],{

/***/ 174:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(175);



// add this to handle exception
__WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
  if (console && console.error) {
    console.error(err);
  }
};

var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
app.$mount();

/***/ }),

/***/ 175:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(177);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_5f477d1d_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(178);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(176)
}
var normalizeComponent = __webpack_require__(2)
/* script */

/* template */

/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-5f477d1d"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_5f477d1d_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src\\pages\\mine\\index.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key.substr(0, 2) !== "__"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-5f477d1d", Component.options)
  } else {
    hotAPI.reload("data-v-5f477d1d", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["a"] = (Component.exports);


/***/ }),

/***/ 176:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 177:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator__);


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

//登录页面

/* harmony default export */ __webpack_exports__["a"] = ({
  components: {},
  data: function data() {
    return {
      listdata: [{
        img: "../../static/images/1.png",
        text: "我的信息",
        path: "../resume/main"
      }, {
        img: "../../static/images/2.png",
        text: "我的发布",
        path: "../myadd/main"
      }, {
        img: "../../static/images/3.png",
        text: "我的申请",
        path: "../mywant/main"
      }, {
        img: "../../static/images/4.png",
        text: "意见与反馈",
        path: "../suggestion/main"
      }, {
        img: "../../static/images/5.png",
        text: "关于我们",
        path: "../about/main"
      }]
    };
  },

  computed: {
    dot: function dot() {
      if (this.$store.default.state.resume.hassee) {

        return "dotshow";
      } else {

        return "dothide";
      }
    }
  },

  methods: {
    test: function test() {
      var _this = this;

      return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee() {
        return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this.$request.request("/test");

              case 2:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, _this);
      }))();
    },
    tomsg: function tomsg() {
      console.log('sssssssssssss');
      this.$WX.navigateTo("../message/main");
    },

    //跳转
    topath: function topath(e) {
      var path = e.currentTarget.id;
      this.$WX.navigateTo(path);
    }
  },

  onShow: function onShow() {
    this.$store.default.commit("setresume");
  }
});

/***/ }),

/***/ 178:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('i-message', {
    attrs: {
      "id": "message",
      "mpcomid": '0'
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "tapbg"
  }, [_c('div', {
    staticClass: "flex    justify-end"
  }, [_c('image', {
    staticClass: "msg",
    attrs: {
      "src": "../../static/images/6.png",
      "eventid": '0'
    },
    on: {
      "click": _vm.tomsg
    }
  }, [_c('div', {
    class: _vm.dot
  })])]), _vm._v(" "), _c('div', {
    staticClass: "flex justify-start align-center mycard shadow"
  }, [_c('div', {
    staticClass: "userimg"
  }, [_c('open-data', {
    attrs: {
      "type": "userAvatarUrl",
      "mpcomid": '1'
    }
  })], 1), _vm._v(" "), _c('div', {
    staticClass: "wlctxt",
    attrs: {
      "eventid": '1'
    },
    on: {
      "click": _vm.test
    }
  }, [_vm._v("\n      你好：\n      "), _c('open-data', {
    attrs: {
      "type": "userNickName",
      "mpcomid": '2'
    }
  })], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "cu-list menu sm-border",
    staticStyle: {
      "margin-top": "100rpx"
    }
  }, _vm._l((_vm.listdata), function(item, index) {
    return _c('div', {
      key: index,
      staticClass: "cu-item",
      attrs: {
        "id": item.path,
        "eventid": '2_' + index
      },
      on: {
        "click": _vm.topath
      }
    }, [_c('div', {
      staticClass: "content flex  align-center"
    }, [_c('image', {
      staticClass: "png",
      attrs: {
        "src": item.img,
        "mode": "aspectFit"
      }
    }), _vm._v(" "), _c('text', {
      staticClass: "text-grey"
    }, [_vm._v(_vm._s(item.text))])])])
  }))], 1)
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-5f477d1d", esExports)
  }
}

/***/ })

},[174]);