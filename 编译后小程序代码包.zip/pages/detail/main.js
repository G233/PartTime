require("../../common/manifest.js")
require("../../common/vendor.js")
global.webpackJsonpMpvue([11],{

/***/ 149:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__index__ = __webpack_require__(150);



// add this to handle exception
__WEBPACK_IMPORTED_MODULE_0_vue___default.a.config.errorHandler = function (err) {
  if (console && console.error) {
    console.error(err);
  }
};

var app = new __WEBPACK_IMPORTED_MODULE_0_vue___default.a(__WEBPACK_IMPORTED_MODULE_1__index__["a" /* default */]);
app.$mount();

/***/ }),

/***/ 150:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(152);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_0dea6bdb_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(153);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(151)
}
var normalizeComponent = __webpack_require__(2)
/* script */

/* template */

/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-0dea6bdb"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_loader_lib_template_compiler_index_id_data_v_0dea6bdb_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_fileExt_template_wxml_script_js_style_wxss_platform_wx_node_modules_mpvue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "src\\pages\\detail\\index.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key.substr(0, 2) !== "__"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-0dea6bdb", Component.options)
  } else {
    hotAPI.reload("data-v-0dea6bdb", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["a"] = (Component.exports);


/***/ }),

/***/ 151:
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ 152:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_assign__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_assign___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_assign__);




//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _require = __webpack_require__(11),
    $Message = _require.$Message;

/* harmony default export */ __webpack_exports__["a"] = ({
  data: function data() {
    return {
      hasdone: false,
      visible: false,
      actions: [{
        name: "取消"
      }, {
        name: "前往",
        color: "#ed3f14"
      }],
      flagcollection: false, //是否收藏
      flagwant: false, //是否申请
      addinfo: false, //显示附加信息弹窗
      message: "",
      job_id: "",
      isme: false,
      job: ""
    };
  },


  computed: {
    commit: function commit() {
      if (!this.flagwant) {
        return "cu-btn round commit lg ";
      } else {
        return "cu-btn round commit done lg ";
      }
    },
    committxt: function committxt() {
      if (!this.flagwant) {
        return "申请";
      } else {
        return "申请中 ";
      }
    },
    hasresume: function hasresume() {
      return this.$store.default.state.resume.hasresume;
    },
    collectionimages: function collectionimages() {
      if (this.flagcollection) {
        return "/static/images/star1.png";
      } else {
        return "/static/images/star.png";
      }
    },
    showmap: function showmap() {
      try {
        return this.job.site.latitude;
      } catch (e) {
        return false;
      }
    }
  },
  onShareAppMessage: function onShareAppMessage(res) {
    console.log(res);
    return {
      title: this.job.name,
      path: "pages/list/main?id=" + this.job._id
    };
  },
  onUnload: function onUnload() {
    __WEBPACK_IMPORTED_MODULE_2_babel_runtime_core_js_object_assign___default()(this.$data, this.$options.data());
  },
  onLoad: function onLoad(options) {
    var _this = this;

    return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee() {
      var job, info;
      return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              //显示顶部加载动画
              wx.showNavigationBarLoading();

              if (!options.id) {
                _context.next = 6;
                break;
              }

              _context.next = 4;
              return _this.$request.postRequest("/getjobd", {
                data: { jobId: options.id }
              });

            case 4:
              job = _context.sent;

              if (job.data.code == 200) {
                _this.job = job.data.data;
                setTimeout(function () {
                  _this.hasdone = true;
                  wx.hideNavigationBarLoading();
                }, 500);
              } else {
                $Message({
                  content: jobs.data.msg,
                  type: "error"
                });
              }

            case 6:
              _context.next = 8;
              return _this.$request.postRequest("/getDstatus", {
                data: { jobId: _this.job._id }
              });

            case 8:
              info = _context.sent;


              if (info.data.code == 500) {
                //都有
                _this.flagcollection = _this.flagwant = true;
              }
              if (info.data.code == 400) {
                //已申请
                _this.flagwant = true;
              }
              if (info.data.code == 300) {
                //已收藏
                _this.flagcollection = true;
              }
              // 是否为自己发布的职位
              if (_this.job.openId == _this.$store.default.state.resume.openId) {
                _this.isme = true;
              }

            case 13:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, _this);
    }))();
  },

  methods: {
    // 点击复制数字
    fuzhi: function fuzhi(index, msg) {
      console.log(msg);
      wx.setClipboardData({
        data: String(msg),
        success: function success(res) {}
      });
    },
    pushdata: function pushdata() {
      this.postmsg("/addwant", { jobId: this.job._id });
      this.addinfo = false;
      console.log(this.message);
      this.message = "";
    },
    handlecancel: function handlecancel() {
      this.addinfo = false;
      this.message = "";
    },
    postmsg: function postmsg(address) {
      var _this2 = this;

      return __WEBPACK_IMPORTED_MODULE_1_babel_runtime_helpers_asyncToGenerator___default()( /*#__PURE__*/__WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.mark(function _callee2() {
        var dat, msg;
        return __WEBPACK_IMPORTED_MODULE_0_babel_runtime_regenerator___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                dat = void 0;

                if (address == "/addwant") {
                  dat = {
                    jobId: _this2.job._id,
                    message: _this2.message
                  };
                } else {
                  dat = { jobId: _this2.job._id };
                }
                console.log(dat);
                _context2.next = 5;
                return _this2.$request.postRequest(address, { data: dat });

              case 5:
                msg = _context2.sent;

                console.log(msg.data, address);
                //console.log(this.job);
                if (msg.data.code == 200) {
                  if (address == "/addwant" || address == "/deletewant") {
                    _this2.flagwant = !_this2.flagwant;
                    console.log(_this2.flagwant, "flagwant");
                  } else {
                    _this2.flagcollection = !_this2.flagcollection;
                    console.log(_this2.flagcollection, "flagcollection");
                  }
                  $Message({
                    content: msg.data.msg,
                    type: "success"
                  });
                } else {
                  $Message({
                    content: msg.data.msg,
                    type: "error"
                  });
                }

              case 8:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, _this2);
      }))();
    },
    want: function want() {
      if (!this.flagwant) {
        if (!this.hasresume) {
          console.log("你还没填资料啊");
          this.visible = true;
          return;
        }
        this.addinfo = true;
      } else {
        this.postmsg("/deletewant");
      }
    },
    collectionclick: function collectionclick() {

      if (this.flagcollection) {
        this.postmsg("/deleteenshrine");
      } else {
        this.postmsg("/addenshrine");
      }
    },
    handleClick: function handleClick(e) {
      if (e.mp.detail.index == 1) {
        this.$WX.navigateTo("../resume/main");
      }
      this.visible = false;
    },
    gotomap: function gotomap() {
      var data = {
        latitude: this.job.site.latitude,
        longitude: this.job.site.longitude

      };
      this.$WX.navigateTo("../showmap/main", data);
    }
  }
});

/***/ }),

/***/ 153:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "margin"
  }, [(_vm.hasdone) ? _c('div', [_c('div', {
    staticClass: "solids-bottom"
  }, [_c('div', {
    staticClass: "flex padding-tb-xl align-center"
  }, [_c('div', {
    staticClass: "tabshu"
  }), _vm._v(" "), _c('div', {
    staticClass: "jobname padding-left"
  }, [_vm._v(_vm._s(_vm.job.name))]), _vm._v(" "), _c('div', {
    staticClass: "leikuang"
  }, [_vm._v(_vm._s(_vm.job.choselei))]), _vm._v(" "), (_vm.job.done) ? _c('div', {
    staticClass: "statu1"
  }, [_vm._v("已完成")]) : _vm._e(), _vm._v(" "), (!_vm.job.done) ? _c('div', {
    staticClass: "statu2"
  }, [_vm._v("申请中")]) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "flex justify-between align-center"
  }, [_c('div', {
    staticClass: "flex padding align-end"
  }, [_c('div', {
    staticClass: "jobsa"
  }, [_vm._v(_vm._s(_vm.job.salary))]), _vm._v(" "), _c('div', {
    staticClass: "text-grey",
    staticStyle: {
      "font-size": "15px"
    }
  }, [_vm._v("元 / " + _vm._s(_vm.job.chosetime))])]), _vm._v(" "), _c('div', {
    staticClass: "flex align-center"
  }, [_c('button', {
    staticClass: "fenxiang",
    attrs: {
      "open-type": "share"
    }
  }, [_c('image', {
    staticClass: "fenxiangpng",
    attrs: {
      "mode": "widthFix",
      "src": "/static/images/fenxiang.png",
      "eventid": '0'
    },
    on: {
      "click": _vm.collectionclick
    }
  })]), _vm._v(" "), (!_vm.job.done && !_vm.isme) ? _c('div', {
    staticClass: "padding margin-tb solid-left"
  }) : _vm._e(), _vm._v(" "), (!_vm.job.done && !_vm.isme) ? _c('image', {
    staticClass: "starpng",
    attrs: {
      "src": _vm.collectionimages,
      "eventid": '1'
    },
    on: {
      "click": _vm.collectionclick
    }
  }) : _vm._e()], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "title1 padding-top-xl"
  }, [_vm._v("「工作内容」")]), _vm._v(" "), _c('div', {
    staticClass: "margin txt1 text-df"
  }, [_vm._v(_vm._s(_vm.job.details))]), _vm._v(" "), _c('div', {
    staticClass: "title1"
  }, [_vm._v("「工作时间」")]), _vm._v(" "), _c('div', {
    staticClass: "margin txt1 text-df"
  }, [_vm._v(_vm._s(_vm.job.time))]), _vm._v(" "), _c('div', {
    staticClass: "title1"
  }, [_vm._v("「工作地点」")]), _vm._v(" "), _c('div', {
    staticClass: "margin txt1"
  }, [(_vm.showmap) ? _c('image', {
    staticClass: "mappng",
    attrs: {
      "src": "/static/images/map.png",
      "eventid": '2'
    },
    on: {
      "click": _vm.gotomap
    }
  }) : _c('div', {
    staticClass: "text-df"
  }, [_vm._v("暂未提供地点信息")])]), _vm._v(" "), (_vm.job.done && _vm.isme) ? _c('div', [_c('div', {
    staticClass: "title1"
  }, [_vm._v("「人员」")]), _vm._v(" "), _vm._l((_vm.job.employee), function(item, index) {
    return _c('div', {
      key: index,
      staticClass: "solid-bottom padding-lr"
    }, [_c('div', {
      staticClass: "flex justify-start align-center padding-top txt1 text-df"
    }, [_c('div', {
      staticStyle: {
        "width": "100rpx"
      }
    }, [_vm._v(_vm._s(item.name))]), _vm._v(" "), _c('div', [_vm._v("   " + _vm._s(item.sex == 1 ? '男' : '女'))])]), _vm._v(" "), _c('div', {
      staticClass: "flex justify-start align-center padding-top txt1 text-df",
      attrs: {
        "eventid": '3_' + index
      },
      on: {
        "click": function($event) {
          _vm.fuzhi(1, item.phone)
        },
        "longpress": function($event) {
          _vm.fuzhi(1, item.phone)
        }
      }
    }, [_c('div', [_vm._v("手机号：")]), _vm._v(" "), _c('div', {
      staticStyle: {
        "color": "#5698c3"
      }
    }, [_vm._v(_vm._s(item.phone))])]), _vm._v(" "), (item.wx) ? _c('div', {
      staticClass: "flex justify-start align-center padding-tb txt1 text-df",
      attrs: {
        "eventid": '4_' + index
      },
      on: {
        "click": function($event) {
          _vm.fuzhi(2, item.wx)
        },
        "longpress": function($event) {
          _vm.fuzhi(2, item.wx)
        }
      }
    }, [_c('div', [_vm._v("微信号：")]), _vm._v(" "), _c('div', {
      staticStyle: {
        "color": "#5698c3"
      }
    }, [_vm._v(_vm._s(item.wx))])]) : _vm._e()])
  })], 2) : _vm._e(), _vm._v(" "), (!_vm.job.done && !_vm.isme) ? _c('div', {
    staticClass: "flex padding justify-center"
  }, [_c('button', {
    class: _vm.commit,
    attrs: {
      "eventid": '5'
    },
    on: {
      "click": _vm.want
    }
  }, [_vm._v(_vm._s(_vm.committxt))])], 1) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "time padding-xl text-grey"
  }, [_vm._v("发布于：" + _vm._s(_vm.job.day))]), _vm._v(" "), _c('i-modal', {
    attrs: {
      "title": "完善资料",
      "visible": _vm.visible,
      "actions": _vm.actions,
      "eventid": '6',
      "mpcomid": '0'
    },
    on: {
      "Click": _vm.handleClick
    }
  }, [_c('view', [_vm._v("完善个人资料后即可申请")])]), _vm._v(" "), (_vm.addinfo) ? _c('view', {
    staticClass: "addmsg"
  }, [_c('view', {
    staticStyle: {
      "height": "40rpx"
    }
  }, [_c('view', {
    staticClass: "button",
    staticStyle: {
      "float": "left"
    },
    attrs: {
      "eventid": '7'
    },
    on: {
      "click": _vm.handlecancel
    }
  }, [_vm._v("取消")]), _vm._v(" "), _c('view', {
    staticClass: "button",
    staticStyle: {
      "float": "right"
    },
    attrs: {
      "eventid": '8'
    },
    on: {
      "click": _vm.pushdata
    }
  }, [_vm._v("提交")])]), _vm._v(" "), _c('view', {
    staticClass: "cu-form-group margin-top"
  }, [_c('textarea', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.message),
      expression: "message"
    }],
    staticClass: "textarea",
    attrs: {
      "maxlength": "-1",
      "placeholder": "在这里填写你想对商家说的话吧",
      "fixed": "true",
      "auto-focus": "true",
      "placeholder-class": "placeholderclass",
      "eventid": '9'
    },
    domProps: {
      "value": (_vm.message)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.message = $event.target.value
      }
    }
  })])]) : _vm._e()], 1) : _c('div', [_c('image', {
    staticClass: "gif-black response",
    staticStyle: {
      "height": "240rpx"
    },
    attrs: {
      "src": "/static/images/loading.gif",
      "mode": "aspectFit"
    }
  })]), _vm._v(" "), _c('i-message', {
    attrs: {
      "id": "message",
      "mpcomid": '1'
    }
  })], 1)
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-0dea6bdb", esExports)
  }
}

/***/ })

},[149]);